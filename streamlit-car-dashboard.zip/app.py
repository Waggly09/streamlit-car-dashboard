import pandas as pd
import plotly.express as px
import streamlit as st

# Encabezado
st.header("🚗 Análisis de Autos Usados en EE.UU.")

# Leer datos
df = pd.read_csv("vehicles_us.csv")

# Histograma
if st.checkbox("Mostrar Histograma de Odómetro"):
    st.write("Distribución del kilometraje de los autos en venta")
    fig = px.histogram(df, x="odometer", title="Distribución del Odómetro")
    st.plotly_chart(fig, use_container_width=True)

# Dispersión
if st.checkbox("Mostrar Dispersión Precio vs Kilometraje"):
    st.write("Relación entre el precio y el kilometraje")
    fig = px.scatter(df, x="odometer", y="price", title="Precio vs Kilometraje")
    st.plotly_chart(fig, use_container_width=True)
