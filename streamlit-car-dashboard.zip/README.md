# Streamlit - Dashboard de Autos Usados

Aplicación web desarrollada con Streamlit que permite visualizar datos de anuncios de autos usados en EE.UU. mediante gráficos interactivos con Plotly.

## Funcionalidades

- Histograma del kilometraje (odómetro)
- Gráfico de dispersión: Precio vs Kilometraje

## Cómo ejecutar

1. Crear entorno virtual e instalar dependencias:
```bash
pip install pandas plotly streamlit nbformat
```

2. Ejecutar app:
```bash
streamlit run app.py
```
